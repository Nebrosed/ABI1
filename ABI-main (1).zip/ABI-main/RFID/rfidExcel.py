import pandas as pd

df= pd.read_excel (r'O:\Equipes\Électrolyse-(Secteur)\ABS\Stagiaire\Été 2021\Programmation des puces RFID\RFID-2020-05-03.xlsx')
print(df)
input("input")