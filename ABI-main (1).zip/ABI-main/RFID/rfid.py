from time import sleep

import nfc
import ndef
from nfc.clf import RemoteTarget

#
# Main function, for when this file is run as a script
#

def menu():
    print("Veuillez choisir: ")
    print("1- Ecrire & verrouiller une serie de tags")
    print("2- Verrouiller des tags")
    print("3- Ecrire un seul tag")
    print("4- Lire un tag")
    choix= input("Choix: ")
    while choix == '1':
        writeSerie()
        break
    while choix == '2':
        lockTags()
        break
    while choix == '3':
        writeSingle()
        break
    while choix == '4':
        readSingle()
        break
    
def readSingle():
    with nfc.ContactlessFrontend('usb:054c:06c1') as clf:
        while True:
            print("Placer le tag sur le lecteur...")
            target = clf.sense(RemoteTarget('106A'))
            if target is None:
                sleep(0.1)  # don't burn the CPU
                continue
            serial = target.sdd_res.hex()
            print("Numero de serie: " + serial + "!")
            tag = nfc.tag.activate(clf, target)
            if tag.ndef:
                print("Tag is NDEF formatted!")
                print("It has " + str(len(tag.ndef.records)) + " records.")
                for record in tag.ndef.records:
                    print("    Record: " + str(record))
            else:
                print("Tag is not NDEF formatted.")
            input("Appuyer sur ENTER pour continuer...")
            menu()
        
def lockTags():
    while True:
        input("Placer le tag et appuyer sur ENTER")
        with nfc.ContactlessFrontend('usb:054c:06c1') as clf:
            while True:
                print("Placer le tag sur le lecteur...")
                target = clf.sense(RemoteTarget('106A'))
                if target is None:
                    sleep(0.1)  # don't burn the CPU
                    continue
                serial = target.sdd_res.hex()
                print("Numero de serie: " + serial + "!")
                tag = nfc.tag.activate(clf, target)
                if tag.ndef:
                    print("Tag is NDEF formatted!")
                    print("It has " + str(len(tag.ndef.records)) + " records.")
                    for record in tag.ndef.records:
                        print("    Record: " + str(record))
                    tag.protect(password=None, read_protect=False, protect_from=0)
                else:
                    print("Tag is not NDEF formatted.")
                input("Appuyer sur ENTER pour continuer...")
                menu()
                
                
def writeSingle():
    input("Veuillez placer le premier tag et peser sur ENTER")
    type=input("Entrer le type d'equipement (ex:CB01): ")
    serialNbr=input("Entrer le numero de serie (ex:60001): ")
    with nfc.ContactlessFrontend('usb:054c:06c1') as clf:
        while True:
            toWrite = str("RFID-"+str(type)+"-"+str(serialNbr))
            target = clf.sense(RemoteTarget('106A'))
            if target is None:
                sleep(0.1)  # don't burn the CPU
                continue
            serial = target.sdd_res.hex()
            print("Found a target with serial " + serial + "!")
            tag = nfc.tag.activate(clf, target)
            if tag.ndef:
                record = ndef.TextRecord(toWrite)
                tag.ndef.records = [record]
                print(toWrite)
                input("Veuillez placer le prochain tag et peser sur ENTER")
            else:
                print("Tag is not NDEF formatted.")
            menu() 
                
                  
def writeSerie():
    type=input("Entrer le type d'equipement (ex:CB01): ")
    serialStart=input("Entrer le premier numero de la serie (ex: 60001): ")
    serialEnd=input("Entrer le dernier numero de la serie (ex:60100): ")
    nbrtag=int(serialEnd)-int(serialStart)+1
    print("Vous allez programer "+ str(nbrtag)+" tags")
    input("Veuillez placer le premier tag et appuyer sur ENTER")
    with nfc.ContactlessFrontend('usb:054c:06c1') as clf:
        while True:
            serialEnd2 = int(serialEnd)+1
            for x in range(int(serialStart), int(serialEnd2)):
                toWrite = str("RFID-"+str(type)+"-"+str(x))
                target = clf.sense(RemoteTarget('106A'))
                if target is None:
                    sleep(0.1)  # don't burn the CPU
                    continue
                serial = target.sdd_res.hex()
                tag = nfc.tag.activate(clf, target)
                if tag.ndef:
                    record = ndef.TextRecord(toWrite)
                    tag.ndef.records = [record]
                    tag.protect(password=None, read_protect=False, protect_from=0)
                    print(toWrite + " est ecrit et verrouiller.")
                    input("Veuillez placer le prochain tag et appuyer sur ENTER")
                else:
                    print("Error: Tag is not NDEF formatted.")
            menu()
                    
if __name__ == '__main__':
    menu()
    

