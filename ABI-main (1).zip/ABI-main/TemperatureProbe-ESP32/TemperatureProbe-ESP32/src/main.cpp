#include <Arduino.h>
#include <SPIFFS.h>
#include <SD.h>
#include <WiFi.h>
#include <NTPClient.h>
#include <ESP32Time.h>
#include <OneWire.h>
#include <Dallastemperature.h>

//WiFi ini
const char* ssid = "iPhone"; //Configurer partage de connection du telephone
const char* password = "ABIabi1234";

//NTP ini
WiFiUDP ntpUDP;
NTPClient timeClient(ntpUDP, "north-america.pool.ntp.org", -14400); //Serveur NTP
String dateTime;
String dayStamp;
String timeStamp;
String formattedDate;
ESP32Time rtc;
bool timeIsSet = false;
bool dateNTP = true; // false = sd - true = serveur NTP

//FTP & SD ini
File tempFile; //fichier Temperature sur SD
File dateFile; //fichier date sur SD

//DS18B20 ini
#define sondeAmbiant 16 //Pin Sonde de temperature Ambiant
OneWire oneWireAmbiant(sondeAmbiant);
DallasTemperature sensorAmbiant(&oneWireAmbiant);
#define sondeIpad 4  //Pin Sonde de temperature iPad
OneWire oneWireIpad(sondeIpad);
DallasTemperature sensorIpad(&oneWireIpad);

//Millis & Timer ini
unsigned long startMillis;
unsigned long startMillisDate;
unsigned long currentMillis;
unsigned long currentMillisDate;
const unsigned long timerWriteSD = 60000; //timer ecriture SD
const unsigned long timerSetTimeNTP = 10000; //timer acquisition heure du serveur

//Function ini
void setTimeNTP();
void writeTempSD(float ipad, float ambiant, String dateTime);
void writeTimeSD(String dateTime);
String readTimeSD();
float getTempAmbiant();
float getTempIpad();
float getTempIpadSerial();

void setup(){
	Serial.begin(115200);
	if(!SD.begin()) // Doit avoir carte SD
	{
		Serial.println("SD Card Mount Failed");
	}
	while (!timeIsSet)
	{
		setTimeNTP(); // Attend d'avoir etablie l'heure soit par serveur NTP ou par lecture sur SD
	}
	startMillis = millis();
	startMillisDate = millis();
}

void loop(){
	currentMillis = millis();
	if (currentMillis - startMillis >= timerWriteSD)
	{
		float ipad = getTempIpad();
		float ambiant = getTempAmbiant();
		dateTime = rtc.getDateTime();
		writeTempSD(ipad, ambiant, dateTime);
		startMillis = currentMillis;
	}
}

void setTimeNTP(){
	//Get NTP
	WiFi.begin(ssid, password);
	currentMillisDate = millis();
	while (WiFi.status() != WL_CONNECTED && currentMillisDate - startMillisDate <= timerSetTimeNTP) //Attend pour connection wifi ou delai de 15sec
	{
		delay(500);
		currentMillisDate = millis();
		//Serial.println((currentMillisDate - startMillisDate)); //Debug
	}
	if (WiFi.status() != WL_CONNECTED) // si pas de connection, prend la date et l'heure sur la SD
	{
		dateTime = readTimeSD();
		//Serial.println("Date et Heure prisent sur la carte SD"); //Debug
		//Serial.println(dateTime); //Debug
		timeIsSet = true;
	}
	else // connection etablie, prend date et heure sur serveur NTP
	{	
		//Serial.println("Wifi connecter"); //debug
		timeClient.begin();
		while(!timeClient.update())
		{
    		timeClient.forceUpdate();
  		}
		//Structure de Date Heure
		unsigned long epochTime = timeClient.getEpochTime();
		struct tm *ptm = gmtime ((time_t *)&epochTime);
		int monthDay = ptm->tm_mday;
		int currentMonth = ptm->tm_mon+1;
		int currentYear = ptm->tm_year+1900;
		rtc.setTime(timeClient.getSeconds(), timeClient.getMinutes(), timeClient.getHours(), monthDay, currentMonth, currentYear);
		dateTime = rtc.getDateTime();
		writeTimeSD(dateTime);
		//Serial.println(readTimeSD()); //Debug
		timeIsSet = true;
		WiFi.disconnect();
	}
}

void writeTempSD(float ipad, float ambiant, String dateTime){ // Ecrire temperature et date sur SD
	tempFile = SD.open("/tempLog6.txt", FILE_APPEND); //Changer Pour la carte Sonde a programmer
	if (tempFile)
	{
		tempFile.print(ipad);
		tempFile.print(" ");
		tempFile.print(ambiant);
		tempFile.print(" ");
		tempFile.print(dateTime);
		tempFile.println("");
		tempFile.close();
	} 
	else
	{
		Serial.println("Erreur d'ouverture.");
	}
}

void writeTimeSD(String dateTime){ // Ecrire date et heure sur SD
	dateFile = SD.open("/date.txt", FILE_WRITE);
	if (dateFile)
	{
		dateFile.print(dateTime);
		dateFile.close();		
	} 
	else
	{
		Serial.println("Erreur d'ouverture.");
	}
}

String readTimeSD(){ //Lire date et heure sur SD si pas de conneciton
	dateFile = SD.open("/date.txt");
	if (dateFile)
	{
		formattedDate = dateFile.readString();
		return formattedDate;
	}
	else
	{
		Serial.println("Erreur d'ouverture.");
		return formattedDate;
	}
}

float getTempAmbiant(){ // Temperature ambiant DS18B20
	float tempinCambiant = 0;
	for (int i = 0; i < 5; i++) // prend la moyenne des 5 dernieres mesures
	{
		sensorAmbiant.requestTemperatures();
		tempinCambiant += sensorAmbiant.getTempCByIndex(0);
	}
	tempinCambiant = tempinCambiant / 5;
	return tempinCambiant;
}

float getTempIpad(){ //Temperature iPad DS18B20
	float tempinCipad = 0;
	for (int i = 0; i < 5; i++) // prend la moyenne des 5 dernieres mesures
	{
		sensorIpad.requestTemperatures();
		tempinCipad += sensorIpad.getTempCByIndex(0);
	}
	tempinCipad = tempinCipad / 5;
	return tempinCipad;
}


