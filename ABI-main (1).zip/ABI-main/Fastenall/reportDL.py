import time
import os
import shutil
from datetime import date, datetime, timedelta
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver import Edge
from selenium.webdriver.firefox.options import Options

def main():
    startDate = datetime.today() - timedelta(days=2)
    startDate = startDate.strftime("%m/%d/%Y")
    url = "https://fastsolutions.mroadmin.com/APEX-Login/inbox_initInbox.action"
    driver = webdriver.Edge('O:\Equipes\Électrolyse-(Secteur)\ABS\Casiers autonome\inc\msedgedriver.exe')
    driver.get(url)
    userName = driver.find_element_by_id('user.login_id')
    userName.send_keys('OlivierFortin')
    passWord = driver.find_element_by_id('user.password')
    passWord.send_keys('Fastenal22')
    passWord.send_keys(Keys.RETURN)
    time.sleep(2)
    driver.find_element_by_link_text('Report Manager').click()
    driver.find_element_by_xpath("//select[@name='reportType']/option[text()='Asset Activity Report']").click()
    time.sleep(2)
    beginDate = driver.find_element_by_id('beginDate')
    beginDate.click()
    beginDate.send_keys(Keys.CONTROL + "a")
    beginDate.send_keys(Keys.DELETE)
    beginDate.send_keys(startDate)
    time.sleep(2)
    driver.find_element_by_link_text('Download XLS').click()
    time.sleep(2)
    src = 'C:/Users/'+ os.getlogin() + '/Downloads/assetActivityReport.xls'
    dest = 'O:/Equipes/Électrolyse-(Secteur)/ABS/Casiers autonome/assetActivityReport.xls'
    shutil.move(src,dest)
    driver.close()

if __name__ == '__main__':
    main()

