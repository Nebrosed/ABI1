
with 
    toto as (
        SELECT TOP 1000 ROW_NUMBER() 
        OVER(PARTITION BY p1.tag_id 
        ORDER BY p1.detection_id DESC) as row_num, 
            p1.detection_id AS ID, 
	        p4.nom, 
	        p1.tag_id AS 'Puce', 
	        p3.nom AS Equipement,
            p3.numero AS Numero, 
	        p1.distance AS Distance, 
	        p1.insert_timestamp AS Date_Heure, 
	        p1.tag_motion AS Moving,
	        p1.reader_uwb_id AS Antenne
				 
        FROM dbo.noovelia_kencee_detection p1 

        INNER JOIN dbo.noovelia_kencee_antenne p4 ON p4.uwb_id = p1.reader_uwb_id /*Join en table Antenne et table Detection */

        INNER JOIN dbo.noovelia_kencee_equipment p3 ON p3.tag_id = p1.tag_id /*Join entre table equipement et table detection*/

        WHERE p1.tag_id = '1564' and p1.reader_uwb_id=16689 /* Choisir Puce et Antenne*/

        ORDER BY p1.detection_id DESC)

SELECT 
	b.Equipement,
    b.Numero,
    b.Puce,
	b.ID,
	b.Antenne,
	b.Moving,
	b.Distance,
	ROUND(b2.Distance - b.Distance,2) AS Parcourue, /*Calcul de la distance parcourur*/
    b.Date_Heure,
	datediff(second, b.Date_Heure, b2.Date_Heure) AS Lapse, /*Calcu du delta de temps*/
	CASE when  /*Si la valeur est NULL, ne calcul pas*/
		datediff(second, b.Date_Heure, b2.Date_Heure)=0 THEN NULL 
	ELSE /* Si non-NULL Calcul la vitesse*/
		ROUND(ABS((b2.Distance - b.Distance) / ( datediff(second, b.Date_Heure, b2.Date_Heure))),2)
	END AS Vitesse

FROM toto AS b

LEFT OUTER JOIN toto AS b2 ON b2.row_num +1 = b.row_num 